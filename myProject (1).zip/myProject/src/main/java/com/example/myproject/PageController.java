package com.example.myproject;

import com.example.myproject.question.Question;

public interface PageController {
    public void initLevel(Question question);
}

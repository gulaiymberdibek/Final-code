package com.example.myproject.question;

import com.example.myproject.DTO.Answer4;

import java.util.*;

public interface Question <T>{

    public boolean checkAnswer(T st);
    public String nextQuestion();
    public void incrementRightAnswerCount();
    public Integer getCountRightAnswer();
    public Integer getCountAnswer();
    public Answer4 answersForQuestion();
    public Integer getLevel();
}

package com.example.myproject.question;

import com.example.myproject.DTO.Answer4;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class QuestionTrueFalse implements Question<Boolean>{
    private List<String> questionList;
    private List<Boolean> answerList;
    private Integer countRightAnswer;
    private Integer currentQuestion;
    private Integer stageLevel;

    public QuestionTrueFalse(String questionsFilePath, String answersFilePath, Integer stageLevel) {
        fillQuestionList(questionsFilePath, stageLevel);
        fillAnswerList(answersFilePath, stageLevel);
        currentQuestion = 0;
        countRightAnswer=0;
        this.stageLevel = stageLevel;
    }

    private void fillAnswerList(String answersFilePath, Integer stageLevel) {
        answerList = readFileAnswer(answersFilePath,stageLevel);
    }


    @Override
    public boolean checkAnswer(Boolean answer){
        Boolean rightAnswer = Boolean.valueOf(answerList.get(currentQuestion - 1));
        return answer==rightAnswer;
    }

    private void fillQuestionList(String questionFilePath, Integer stageLevel) {
        questionList = readFile(questionFilePath,stageLevel);

    }
    public String nextQuestion(){
        currentQuestion++;
        if (currentQuestion > questionList.size()){
            return "";
        }
        return questionList.get(currentQuestion-1);
    }

    public void incrementRightAnswerCount() {
        countRightAnswer++;
    }

    public Integer getCountRightAnswer() {
        return countRightAnswer;
    }

    @Override
    public Integer getCountAnswer() {
        return questionList.size();
    }

    @Override
    public Answer4 answersForQuestion() {
        return null;
    }

    @Override
    public Integer getLevel() {
        return this.stageLevel;
    }

    private List<String> readFile(String filePath, Integer stageLevel) {
        List<String> lines = new ArrayList<>();
        filePath = "files\\"+ stageLevel.toString() + "\\"+ filePath;

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                lines.add(line);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return lines;
    }

    private List<Boolean> readFileAnswer(String filePath, Integer stageLevel) {
        List<Boolean> lines = new ArrayList<>();
        filePath = "files\\"+ stageLevel.toString() + "\\"+ filePath;

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                Boolean answer = line.equalsIgnoreCase("true")?true:false;
                lines.add(answer);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return lines;
    }

}

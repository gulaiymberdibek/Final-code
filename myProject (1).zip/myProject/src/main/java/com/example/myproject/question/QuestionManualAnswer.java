package com.example.myproject.question;

import com.example.myproject.DTO.Answer4;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class QuestionManualAnswer implements Question<String> {
    private List<String> questionList;
    private List<String> answerList;
    private Integer countRightAnswer;
    private Integer currentQuestion;
    private Integer stageLevel;

    public QuestionManualAnswer(String questionsFilePath, String answersFilePath, Integer stageLevel) {
        fillQuestionList(questionsFilePath, stageLevel);
        fillAnswerList(answersFilePath, stageLevel);
        currentQuestion = 0;
        countRightAnswer = 0;
        this.stageLevel = stageLevel;
    }

    private void fillAnswerList(String answersFilePath, Integer stageLevel) {
        answerList = readFile(answersFilePath, stageLevel);
    }

    @Override
    public boolean checkAnswer(String answer) {
        String rightAnswer = answerList.get(currentQuestion - 1);
        return rightAnswer.equalsIgnoreCase(answer);
    }

    private void fillQuestionList(String questionsFilePath, Integer stageLevel) {
        questionList = readFile(questionsFilePath, stageLevel);
    }

    private List<String> readFile(String filePath, Integer stageLevel) {
        List<String> lines = new ArrayList<>();
        filePath = "files\\" + stageLevel.toString() + "\\" + filePath;

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                lines.add(line);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return lines;
    }

    public String nextQuestion() {
        currentQuestion++;
        if (currentQuestion > questionList.size()) {
            return "";
        }
        return questionList.get(currentQuestion - 1);
    }

    public void incrementRightAnswerCount() {
        countRightAnswer++;
    }

    public Integer getCountRightAnswer() {
        return countRightAnswer;
    }

    @Override
    public Integer getCountAnswer() {
        return questionList.size();
    }

    @Override
    public Answer4 answersForQuestion() {
        return null;
    }

    @Override
    public Integer getLevel() {
        return this.stageLevel;
    }

}
package com.example.myproject;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import com.example.myproject.question.Question;
import com.example.myproject.question.Question4Answer;
import com.example.myproject.question.QuestionManualAnswer;
import com.example.myproject.question.QuestionTrueFalse;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class ChoiceTypeController {

    private int stageLevel;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button btnQuestions1;

    @FXML
    private Button btnQuestions2;

    @FXML
    private Button btnQuestions3;

    @FXML
    private Button btnToStart;

    @FXML
    void nextWindow1(ActionEvent event) {

    }

    @FXML
    void nextWindow2(ActionEvent event) {

    }

    @FXML
    void nextWindow3(ActionEvent event) {

    }

    public void initialize1(int stageLevel) {
        //Сюда мы получаем номер уровня, для загрузки правильных файлов вопросов
        this.stageLevel = stageLevel;
    }

    @FXML
    void initialize() {
    }

    private void runWindow(Integer type) throws IOException {
        String path = "";
        FXMLLoader fxmlLoader = null;
        PageController controller;
        Question question=null;
        switch (type) {
            case (1):
                path = "/com/example/myproject/page3Manual.fxml";
                question = new QuestionManualAnswer("questionsFile.txt", "answersFile.txt",stageLevel);
                break;
            case (2):
                path = "/com/example/myproject/page3True.fxml";
                question = new QuestionTrueFalse("questionsTFFile.txt", "answersTFFile.txt", stageLevel);
                break;
            case (3):
                path = "/com/example/myproject/page3variants.fxml";
                question = new Question4Answer("question4File.txt","answers4File.txt", stageLevel);
                break;
        }
        if (!path.isEmpty()) {
            Stage stage = (Stage) btnQuestions1.getScene().getWindow();
            // do what you have to do
            stage.close();
            fxmlLoader = new FXMLLoader(getClass().getResource(path));

            Parent root1 = (Parent) fxmlLoader.load();
            stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setTitle("Другая форма");
            stage.setScene(new Scene(root1));
            stage.show();
            controller = fxmlLoader.getController();
            controller.initLevel(question);
        }
    }

    @FXML
    void window1() throws IOException {
        runWindow(1);
    }

    @FXML
    void window2() throws IOException {
        runWindow(2);
    }

    @FXML
    void window3() throws IOException {
        runWindow(3);
    }

    public void back() throws IOException {
        Stage stage = (Stage) btnToStart.getScene().getWindow();
        // do what you have to do
        stage.close();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/myproject/page2.fxml"));
        Parent root1 = (Parent) fxmlLoader.load();
        stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Другая форма");
        stage.setScene(new Scene(root1));
        stage.show();

    }
}

package com.example.myproject;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import com.example.myproject.question.FasadeRezult;
import com.example.myproject.question.Question;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class Page3ManualController implements PageController{
    private Question questions;
    boolean rez;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextArea textArea;

    @FXML
    private TextField answer;

    @FXML
    private Button ileri, geri;

    @FXML
    private Button check;

    @FXML
    void initialize() {
    }

    @FXML
    void nextQuestion() throws IOException {
        if (rez){
            questions.incrementRightAnswerCount();
        }
        rez=false;
        String nextQuestion=questions.nextQuestion();
        if (!nextQuestion.isEmpty()) {
            textArea.setText(nextQuestion);
            answer.setText("");
            answer.setStyle("");
        }else{
            Stage stage = (Stage) geri.getScene().getWindow();
            // do what you have to do
            stage.close();
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/myproject/pageStats.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            stage = new Stage();
            StatsController1 answerController = fxmlLoader.getController();
            answerController.setQuestions(questions);
            answerController.showStatistic1();//Здесь ответы шыгарады
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setTitle("Другая форма");
            stage.setScene(new Scene(root1));
            stage.show();
//            Завершающая страница
            showStatistic1();
        }
    }

    private void showStatistic1() {
        FasadeRezult rezult = new FasadeRezult();
        String rez = rezult.rezult(questions);

        check.setDisable(true);
        textArea.setText(rez);

    }

    @FXML
    void checkAnswer() {
        String answerText = answer.getText();

        rez = questions.checkAnswer(answerText);
        if (rez) {
            answer.setStyle("-fx-background-color:GREEN");
        }else{
            answer.setStyle("-fx-background-color:RED");
        }
    }

    @Override
    public void initLevel(Question question) {
        this.questions = question;
        textArea.setText(questions.nextQuestion());
        rez = false;
    }

    public void back() throws IOException {
        Stage stage = (Stage) geri.getScene().getWindow();
        // do what you have to do
        stage.close();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/myproject/ChoiceType.fxml"));
        Parent root1 = (Parent) fxmlLoader.load();
        stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Другая форма");
        stage.setScene(new Scene(root1));
        stage.show();
        ChoiceTypeController controller = fxmlLoader.getController();
        controller.initialize1(questions.getLevel());

    }
}

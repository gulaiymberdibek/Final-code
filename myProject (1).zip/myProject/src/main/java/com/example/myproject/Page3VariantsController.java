package com.example.myproject;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import com.example.myproject.DTO.Answer4;
import com.example.myproject.question.FasadeRezult;
import com.example.myproject.question.Question;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class Page3VariantsController  implements PageController{
    private Question questions;
    boolean rez;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button geri;

    @FXML
    private Button ileri3;

    @FXML
    private TextArea textArea3;

    @FXML
    private Button var1;

    @FXML
    private Button var2;

    @FXML
    private Button var3;

    @FXML
    private Button var4;


    @FXML
    void nextQuestion(ActionEvent event) throws IOException {

        if (rez) {
            questions.incrementRightAnswerCount();
        }
        rez = false;
        String nextQuestion = questions.nextQuestion();
        if (!nextQuestion.isEmpty()) {
            Answer4 answer4 = questions.answersForQuestion();
            textArea3.setText(nextQuestion);
            var1.setText(answer4.getAnswer1());
            var2.setText(answer4.getAnswer2());
            var3.setText(answer4.getAnswer3());
            var4.setText(answer4.getAnswer4());

            var1.setStyle("-fx-background-color:BLACK");
            var2.setStyle("-fx-background-color:GREY");
            var3.setStyle("-fx-background-color:GREY");
            var4.setStyle("-fx-background-color:BLACK");
        } else {
            Stage stage = (Stage) geri.getScene().getWindow();
            // do what you have to do
            stage.close();
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/myproject/pageStats.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            stage = new Stage();
            StatsController1 answerController = fxmlLoader.getController();
            answerController.setQuestions(questions);
            answerController.showStatistic1();//Здесь ответы шыгарады
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setTitle("Другая форма");
            stage.setScene(new Scene(root1));
            stage.show();
            showStatistic1();
        }
    }
    private void showStatistic1( ) {
        FasadeRezult rezult = new FasadeRezult();
        String rez = rezult.rezult(questions);
        textArea3.setText(rez);

    }

    @FXML
    void initialize() {
//        assert geri3 != null : "fx:id=\"geri3\" was not injected: check your FXML file 'page3variants.fxml'.";
//        assert ileri3 != null : "fx:id=\"ileri3\" was not injected: check your FXML file 'page3variants.fxml'.";
//        assert textArea3 != null : "fx:id=\"textArea3\" was not injected: check your FXML file 'page3variants.fxml'.";
//        assert var1 != null : "fx:id=\"var1\" was not injected: check your FXML file 'page3variants.fxml'.";
//        assert var2 != null : "fx:id=\"var2\" was not injected: check your FXML file 'page3variants.fxml'.";
//        assert var3 != null : "fx:id=\"var3\" was not injected: check your FXML file 'page3variants.fxml'.";
//        assert var4 != null : "fx:id=\"var4\" was not injected: check your FXML file 'page3variants.fxml'.";


    }

    @FXML
    void btn1Check(ActionEvent event) {
        String answer = var1.getText();
        rez = questions.checkAnswer(answer);
        if (rez) {
            var1.setStyle("-fx-background-color:GREEN");
        } else {
            var1.setStyle("-fx-background-color:RED");
        }
    }

    @FXML
    void btn2Check(ActionEvent event) {
        String answer = var2.getText();
        rez = questions.checkAnswer(answer);
        if (rez) {
            var2.setStyle("-fx-background-color:GREEN");
        } else {
            var2.setStyle("-fx-background-color:RED");
        }
    }

    @FXML
    void btn3Check(ActionEvent event) {
        String answer = var3.getText();
        rez = questions.checkAnswer(answer);
        if (rez) {
            var3.setStyle("-fx-background-color:GREEN");
        } else {
            var3.setStyle("-fx-background-color:RED");
        }
    }

    @FXML
    void btn4Check(ActionEvent event) {
        String answer = var4.getText();
        rez = questions.checkAnswer(answer);
        if (rez) {
            var4.setStyle("-fx-background-color:GREEN");
        } else {
            var4.setStyle("-fx-background-color:RED");
        }
    }


    @Override
    public void initLevel(Question question) {
        this.questions = question;
        String questionText  =questions.nextQuestion();
        Answer4 answer4 = questions.answersForQuestion();

        textArea3.setText(questionText);
        var1.setText(answer4.getAnswer1());
        var2.setText(answer4.getAnswer2());
        var3.setText(answer4.getAnswer3());
        var4.setText(answer4.getAnswer4());
        rez=false;
    }

    public void back() throws IOException {
        Stage stage = (Stage) geri.getScene().getWindow();
        // do what you have to do
        stage.close();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/myproject/ChoiceType.fxml"));
        Parent root1 = (Parent) fxmlLoader.load();
        stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Другая форма");
        stage.setScene(new Scene(root1));
        stage.show();
        ChoiceTypeController controller = fxmlLoader.getController();
        controller.initialize1(questions.getLevel());

    }
}

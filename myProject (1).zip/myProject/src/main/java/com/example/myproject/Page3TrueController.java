package com.example.myproject;

import com.example.myproject.question.FasadeRezult;
import com.example.myproject.question.Question;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class Page3TrueController implements PageController {
    private Question questions;
    boolean rez;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextArea textArea;


    @FXML
    private Button ileri, geri;

    @FXML
    private Button yes;

    @FXML
    private Button no;

    @FXML
    void initialize() {

//        answer.setStyle("-fx-background-color:RED");
//        answer.setText(questions.nextQuestion());
    }

    @FXML
    void nextQuestion() throws IOException {
        if (rez) {
            questions.incrementRightAnswerCount();
        }
        rez = false;
        String nextQuestion = questions.nextQuestion();
        if (!nextQuestion.isEmpty()) {
            textArea.setText(nextQuestion);
            yes.setStyle("-fx-background-color:BLACK");
            no.setStyle("-fx-background-color:BLACK");
        } else {
            Stage stage = (Stage) geri.getScene().getWindow();
            // do what you have to do
            stage.close();
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/myproject/pageStats.fxml"));
            Parent root1 = (Parent) fxmlLoader.load();
            stage = new Stage();
            StatsController1 answerController = fxmlLoader.getController();
            answerController.setQuestions(questions);
            answerController.showStatistic1();//Здесь ответы шыгарады
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setTitle("Другая форма");
            stage.setScene(new Scene(root1));
            stage.show();
//            Завершающая страница
            showStatistic1();
        }
    }

    private void showStatistic1() {
        FasadeRezult rezult = new FasadeRezult();
        String rez = rezult.rezult(questions);
        textArea.setText(rez);

    }

    @FXML
    public void Yes() {
        checkAnswer(true);
    }

    @FXML
    public void No() {
        checkAnswer(false);
    }

    void checkAnswer(boolean b) {

//        String answerText = b ? "True" : "False";
        Boolean answerText = b;

        rez = questions.checkAnswer(answerText);

        if (b) {
            if (rez) {
                yes.setStyle("-fx-background-color:GREEN");
            } else {
                yes.setStyle("-fx-background-color:RED");
            }
            no.setStyle("-fx-background-color:BLACK");
        } else {
            if (rez) {
                no.setStyle("-fx-background-color:GREEN");
            } else {
                no.setStyle("-fx-background-color:RED");
            }
            yes.setStyle("-fx-background-color:BLACK");
        }

    }

    @Override
    public void initLevel(Question question) {
        this.questions = question;
        textArea.setText(questions.nextQuestion());
        rez = false;
    }

    public void back() throws IOException {
        Stage stage = (Stage) geri.getScene().getWindow();
        // do what you have to do
        stage.close();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/myproject/ChoiceType.fxml"));
        Parent root1 = (Parent) fxmlLoader.load();
        stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Другая форма");
        stage.setScene(new Scene(root1));
        stage.show();
        ChoiceTypeController controller = fxmlLoader.getController();
        controller.initialize1(questions.getLevel());

    }
}
package com.example.myproject.question;

public class FasadeRezult {
    public String rezult(Question question){
        StringBuilder stBuilder = new StringBuilder("");
        stBuilder.append(question.getCountRightAnswer())
                .append("/")
                .append(question.getCountAnswer());

        return stBuilder.toString();
    }
}

package com.example.myproject;

import com.example.myproject.question.FasadeRezult;
import com.example.myproject.question.Question;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;


public class StatsController1 {

    public Button btnToStart;
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;
    @FXML
    private Button geri;
    private Question questions;
    @FXML
    private TextArea score;

    public void setQuestions(Question questions) {
        this.questions = questions;
    }

    public void showStatistic1() {
        FasadeRezult rezult = new FasadeRezult();
        String rez = rezult.rezult(questions);
        score.setText(rez);

    }

    @FXML
    void initialize() {

    }

    public void back() throws IOException {
        Stage stage = (Stage) btnToStart.getScene().getWindow();
        // do what you have to do
        stage.close();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/myproject/hello-view.fxml"));
        Parent root1 = (Parent) fxmlLoader.load();
        stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Другая форма");
        stage.setScene(new Scene(root1));
        stage.show();
    }
}

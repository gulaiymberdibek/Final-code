package com.example.myproject.question;

import com.example.myproject.DTO.Answer4;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

public class Question4Answer implements Question<String> {
    private List<String> questionList;
    private List<Answer4> answerList;

    private Integer countRightAnswer;
    private Integer currentQuestion;
    private Integer stageLevel;

    public Question4Answer(String questionsFilePath, String answersFilePath, Integer stageLevel) {
        fillQuestionList(questionsFilePath, stageLevel);
        fillAnswerList(answersFilePath, stageLevel);
        currentQuestion = 0;
        countRightAnswer = 0;
        this.stageLevel = stageLevel;
    }

    private void fillAnswerList(String answersFilePath, Integer stageLevel) {
        answersFilePath = "files\\"+ stageLevel.toString() + "\\"+ answersFilePath;
        answerList = readFile(answersFilePath);
    }

    @Override
    public boolean checkAnswer(String answer) {
        String rightAnswer = answerList.get(currentQuestion - 1).getRightAnswer();
        return rightAnswer.equalsIgnoreCase(answer);
    }

    private void fillQuestionList(String questionsFilePath, Integer stageLevel) {
        questionsFilePath = "files\\"+ stageLevel.toString() + "\\"+ questionsFilePath;

        questionList = readFileQuestion(questionsFilePath);
    }

    private List<Answer4> readFile(String filePath) {
        List<Answer4> lines = new ArrayList<>();
        Answer4 answer4;

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            String right = "";
            while ((line = br.readLine()) != null) {
                String[] rez = line.split(";");
                for (int i = 0; i < rez.length; i++) {
                    if (rez[i].charAt(0) == '*') {

                        right = rez[i].substring(1, rez[i].length());
                        rez[i] = right;
                    }
                }
                answer4 = new Answer4(right.strip(), rez[0].strip(), rez[1].strip(), rez[2].strip(), rez[3].strip());
                lines.add(answer4);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return lines;
    }

    public String nextQuestion() {
        currentQuestion++;
        if (currentQuestion > questionList.size()) {
            return "";
        }
        return questionList.get(currentQuestion - 1);
    }

    public Answer4 answersForQuestion() {
        return answerList.get(currentQuestion - 1);
    }

    @Override
    public Integer getLevel() {
        return this.stageLevel;
    }

    public void incrementRightAnswerCount() {
        countRightAnswer++;
    }

    public Integer getCountRightAnswer() {
        return countRightAnswer;
    }

    private List<String> readFileQuestion(String filePath) {
        List<String> lines = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                lines.add(line);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return lines;
    }

    @Override
    public Integer getCountAnswer() {
        return questionList.size();
    }

}
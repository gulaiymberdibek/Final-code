package com.example.myproject;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class Page2Controller {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button btn1;

    @FXML
    private Button btn2;

    @FXML
    private Button btn3;

    @FXML
    private Button btn4;

    @FXML
    private Button btn5;

    @FXML
    private Button btn6;

    @FXML
    private Button geri;

    @FXML
    private TextArea textArea;
    @FXML
    void initialize() {
//        assert btn1 != null : "fx:id=\"btn1\" was not injected: check your FXML file 'page2.fxml'.";
//        assert btn2 != null : "fx:id=\"btn2\" was not injected: check your FXML file 'page2.fxml'.";
//        assert btn3 != null : "fx:id=\"btn3\" was not injected: check your FXML file 'page2.fxml'.";
//        assert btn4 != null : "fx:id=\"btn4\" was not injected: check your FXML file 'page2.fxml'.";
//        assert btn5 != null : "fx:id=\"btn5\" was not injected: check your FXML file 'page2.fxml'.";
//        assert btn6 != null : "fx:id=\"btn6\" was not injected: check your FXML file 'page2.fxml'.";
//        assert geriBasla != null : "fx:id=\"geriBasla\" was not injected: check your FXML file 'page2.fxml'.";

    }
    public void back() throws IOException {
        Stage stage = (Stage) geri.getScene().getWindow();
        stage.close();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/myproject/hello-view.fxml"));
        Parent root1 = (Parent) fxmlLoader.load();
        stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Другая форма");
        stage.setScene(new Scene(root1));
        stage.show();
    }
    @FXML
    void nextWindow1() throws IOException {
        runStage(1);
    }
    @FXML
    void nextWindow2() throws IOException {
        runStage(2);
    }
    @FXML
    void nextWindow3() throws IOException {
        runStage(3);
    }
    @FXML
    void nextWindow4() throws IOException {
        runStage(4);
    }
    @FXML
    void nextWindow5() throws IOException {
        runStage(5);
    }
    @FXML
    void nextWindow6() throws IOException {
        runStage(6);
    }


    private void runStage(int stageLevel) throws IOException {
        Stage stage = (Stage) btn1.getScene().getWindow();
        stage.close();
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/myproject/ChoiceType.fxml"));
        Parent root1 = (Parent) fxmlLoader.load();

        ChoiceTypeController controller = fxmlLoader.getController();
        controller.initialize1(stageLevel);

        stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Другая форма");
        stage.setScene(new Scene(root1));
        stage.show();

    }
}
